//
//  DSLHKIDCardSDK.h
//  DSLHKIDCardDemo
//
//  Created by chentao on 2018/7/5.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol DSLHKIDCardDetectObserverDelegate;

@interface DSLHKIDCardSDK : NSObject

/**
 开始检测
 */
+(void)startDetect;

/**
 识别结束时重置状态
 注意:目前不需要外部调用重置状态,SDK内部会重置
 */
+(void)resetStatus;

/**
 退出(离开页面的时候)时调用，把对象销毁
 */
+(void)destroyOCR;

/**
 回调对象注册接口
 
 @param observer 回调对象
 */
+(void)registerObserver:(id<DSLHKIDCardDetectObserverDelegate>_Nonnull)observer;

/**
 回调对象注销接口
 
 @param observer 回调对象
 */
+(void)unregisterObserver:(id<DSLHKIDCardDetectObserverDelegate>_Nonnull)observer;

/**
 图片识别传入
 
 @param imageData imageData 图片
 @param orient 传入的图片方向
 @param lensPosition lensPosition 焦距
 */
+(void)addDetectBufferData:(NSData *_Nonnull)imageData Orient:(int)orient LensPosition:(float)lensPosition;

/**
 设置证件类型
 
 @param isNewIDCard YES:新证件；NO:老证件
 @param useLiteVersion 是否启用Lite版本:，YES：启用，NO：不启用
 @param bOcclusion_check 是否开启手指遮挡检测：YES：启用，NO：不启用
 @param exposure_t 范围0-1， 曝光检测系数，数值越低越严格，更松的数值推荐为0.2，不启用为1，默认值是 0.1
 @param dark_t 范围0-1 ，昏暗检测系数，数值越越低越严格。更松的数值推荐为0.95，不启用为1， 默认值是0.9
 @param stop_t1_2003 范围0-1，2003证件：翻转证件成功后停止阶段允许的抖动范围，数值越低越严格。更松的数值推荐为0.95，不启用为1， 默认值是0.9
 @param stop_t2_2003 范围0-1，2003证件：重置证件成功后停止阶段允许的抖动范围，数值越高越严格。更松的数值推荐为0.85，不启用为0，默认值是0.95
 @param stop_t1_2018 范围0-1，2018证件：翻转证件成功后停止阶段允许的抖动范围，数值越低越严格。更松的数值推荐为0.95，不启用为1， 默认值是0.9
 @param stop_t2_2018 范围0-1，2018证件：重置证件成功后停止阶段允许的抖动范围，数值越高越严格。更松的数值推荐为0.85，不启用为0，默认值是0.95
 */
+(void)setIDCardType:(BOOL)isNewIDCard UseLietVersion:(BOOL)useLiteVersion Occlusion_check:(BOOL)bOcclusion_check Exposure_t:(double)exposure_t Dark_t:(double)dark_t Stop_t1_03:(double) stop_t1_2003 Stop_t2_03:(double) stop_t2_2003 Stop_t1_2018:(double)stop_t1_2018 Stop_t2_2018:(double) stop_t2_2018;

/**
 获取当前SDK版本号
 
 @return 当前版本号
 */
+(NSString *_Nonnull)getVersion;

/**
 设置识别超时时间;
 
 @param times 单位:秒, 默认是30s;
 */
+ (void)setOverTimes:(int)times;

/**
 开始识别超时计时

 */
+ (void)startOverTime;

/**
 停止识别超时计时
 
 */
+ (void)stopOverTimer;

/**
 视频安全签名
 
 @param videoPath 已经录制好的视频路径
 @param imgIDCard 静态证件图片(识别成功后，DSLHKIDCardResult结果返回的静态证件图片)
 @param videoTimeStamp 视频时间戳拼接字符串(如:视频开始时间|第一个动作识别结束时间|第二个动作识别结束时间(打开闪光灯录制视频时间)|视频结束时间)
 @return 一个字典结构，包括:signature和custom
 */
+ (NSMutableDictionary* _Nonnull)signatureWithVideoFile:(NSString* _Nonnull)videoPath TemplateImage:(NSString* _Nonnull) imgIDCard VideoTimeStamp:(NSString* _Nonnull)videoTimeStamp;

/**
 静态图片安全签名

 @param imgIDCard 静态证件图片(识别成功后，DSLHKIDCardResult结果返回的静态证件图片)
 @return 一个字典结构，包括:signature和custom
 */
+ (NSMutableDictionary* _Nonnull)signatureWithImg:(NSData* _Nonnull)imgIDCard;

/**
 SDK日志是否需要输出
 默认值: Debug模式是YES; Release模式是NO
 @param enable YES: 输出; NO: 不输出
 */
+(void)printLog:(BOOL)enable;


/**
 设置appId
 @param appId 这个appId需要由提供方分配
*/
+(void)setAppId:(NSString* _Nonnull )appId;

@end
